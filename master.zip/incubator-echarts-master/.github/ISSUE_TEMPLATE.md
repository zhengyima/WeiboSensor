<!--
Please Use https://ecomfe.github.io/echarts-issue-helper to create the issue.
Otherwise, it will be closed immediately.
Questions in the form of *How to use ...* should be at Stack Overflow rather than GitHub issue list.

请注意，所有 issue 必须由 https://ecomfe.github.io/echarts-issue-helper/?lang=zh-cn 创建，不然将会被直接关闭。
Issues 中不要问「如何使用 ECharts 实现……功能」的问题，相关问题请到 SegmentFault 或 Stack Overflow 提问，详见上面的链接。
-->

This issue is not created by [echarts-issue-helper](https://ecomfe.github.io/echarts-issue-helper) and will be soon closed.
